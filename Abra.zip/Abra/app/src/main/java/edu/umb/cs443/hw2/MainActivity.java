package edu.umb.cs443.hw2;

import android.annotation.SuppressLint;
import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/*
    Abbreviations:
    h = height
    w = width
    m = move
    t = tiles
    p = player
*/

public class MainActivity extends Activity {

    protected DBHelper mDBHelper;
    int wins = 0;
    int losses = 0;
    GridView gridView;
    HorizontalScrollView hsv;
    TextView textView;
    TextView scoreboard;

    final String EMPTY = " ";
    final String USER = "X";
    final String OPPONENT = "O";
    final String AVAILABLE = "*";

    int h = 20; // must be even and minimum 10
    int w = 19; // must be odd and minimum 9
    String[] t = new String[h * w];
    boolean userCanMove = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get references
        gridView = findViewById(R.id.gridView1);
        hsv = findViewById(R.id.scrollView);
        textView = findViewById(R.id.announcement);
        scoreboard = findViewById(R.id.record);

        // set up database and update the win loss record
        mDBHelper = new DBHelper(this);
        wins = mDBHelper.getWins();
        losses = mDBHelper.getLosses();
        updateScoreboard();

        init();

        // click listener on all tiles
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int m, long id) {
                onClick(m);
            }
        });
    }

    // on click handler for the tiles
    void onClick(int m) {
        if (userCanMove) {
            userCanMove = false;
            if (validateMove(m)) {
                makeMove(m, USER);

                // update view
                adjustGridSize(); // NOTE: I should do this conditionally to avoid waste
                ((ArrayAdapter) gridView.getAdapter()).notifyDataSetChanged();

                // check win
                if (checkForWinner(USER)) {
                    removeAvailableTiles();
                    textView.setText("YOU WIN!");
                    wins++;
                    updateScoreboard();
                    mDBHelper.updateWins(wins);
                } else {

                    // if user hasn't won, computer moves
                    textView.setText("Computer thinking...");
                    Thread computer = new Thread(computerThread);
                    computer.start();
                }
            }
        }
    }

    // check if a move is legal or not
    boolean validateMove(int m) {
        if (m < 0 || m >= t.length) return false;
        else return (t[m] == AVAILABLE);
    }

    // player p makes move m
    void makeMove(int m, String p) {
        t[m] = p;

        // indicate adjacent tiles are available
        if (t[m + 1] == EMPTY) t[m + 1] = AVAILABLE;
        if (t[m - 1] == EMPTY) t[m - 1] = AVAILABLE;
        if (t[m + w] == EMPTY) t[m + w] = AVAILABLE;
        if (t[m - w] == EMPTY) t[m - w] = AVAILABLE;

        // expand board if needed
        if (m % w < 4) addTiles("left");
        else if (m % w >= w - 4) addTiles("right");
        else if (m / w < 4) addTiles("top");
        else if (m / w >= h - 4) addTiles("bottom");
    }

    // check if one player has won the game
    boolean checkForWinner(String p) {
        for (int i = 0; i < t.length; i++) {
            if (t[i] == p) {

                // check horizontal, vertical, and both diagonals for a five in a row
                if ((t[i-2] == p && t[i-1] == p && t[i+1] == p && t[i+2] == p)
                        || (t[i-w*2] == p && t[i-w] == p && t[i+w] == p && t[i+w*2] == p)
                        || (t[i-w*2-2] == p && t[i-w-1] == p && t[i+w+1] == p && t[i+w*2+2] == p)
                        || (t[i-w*2+2] == p && t[i-w+1] == p && t[i+w-1] == p && t[i+w*2-2] == p)) {
                    return true;
                }
            }
        }
        return false;
    }

    // update the text of the wins and losses
    void updateScoreboard() {
        scoreboard.setText("Wins: " + wins + "\nLosses: " + losses);
    }

    // after someone has won we should remove all the available t
    void removeAvailableTiles() {
        for (int i = 0; i < t.length; i++) {
            if (t[i] == AVAILABLE) t[i] = EMPTY;
        }
    }

    // adds t to the board when needed, creating an infinite board
    void addTiles(String direction) {
        String[] newTiles;

        if (direction == "left") {
            w++;
            newTiles = new String[h * w];
            int j = 0;
            for (int i = 0; i < t.length; i++) {
                if (j % w == 0) {
                    newTiles[j] = EMPTY;
                    j++;
                }
                newTiles[j] = t[i];
                j++;
            }
        }

        else if (direction == "right") {
            w++;
            newTiles = new String[h * w];
            int j = 0;
            for (int i = 0; i < t.length; i++) {
                if (j % w == w - 1) {
                    newTiles[j] = EMPTY;
                    j++;
                }
                newTiles[j] = t[i];
                j++;
            }
            newTiles[h * w - 1] = EMPTY;
        }

        else if (direction == "top") {
            h++;
            newTiles = new String[h * w];
            for (int i = 0; i < w; i++) {
                newTiles[i] = EMPTY;
            }
            for (int i = 0; i < t.length; i++) {
                newTiles[i + w] = t[i];
            }
        }

        else { // if (direction == "bottom")
            h++;
            newTiles = new String[h * w];
            for (int i = 0; i < t.length; i++) {
                newTiles[i] = t[i];
            }
            for (int i = t.length; i < h * w; i++) {
                newTiles[i] = EMPTY;
            }
        }

        t = newTiles;
    }

    // runnable for computer logic
    private Runnable computerThread = new Runnable () {
        private static final int DELAY = 1000;
        public void run() {
            try {
                Thread.sleep(DELAY);
                makeMove(computerMove(), OPPONENT);
                threadHandler.sendEmptyMessage(0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };

    // handler allows threads to update the view
    public Handler threadHandler = new Handler() {
        @SuppressLint("HandlerLeak")
        public void handleMessage (android.os.Message message) {
            if (checkForWinner(OPPONENT)) {
                userCanMove = false;
                removeAvailableTiles();
                textView.setText("YOU LOSE.");
                losses++;
                updateScoreboard();
                mDBHelper.updateLosses(losses);
            } else {
                textView.setText("Your turn");
                userCanMove = true;
            }
            adjustGridSize(); // NOTE: I should do this conditionally to avoid waste
            ((ArrayAdapter) gridView.getAdapter()).notifyDataSetChanged();
        }
    };

    // this adjusts the view after we add more tiles to the tiles list
    void adjustGridSize() {
        gridView.setNumColumns(w);
        gridView.setAdapter(new ArrayAdapter<String>(this, R.layout.list_item, t));
    }

    // calculate the best move in the current tiles
    // NOTE: I chose a simple approach. efficiency and accuracy can be improved
    int computerMove() {
        int bestMove = 1;
        double bestScore = -1;

        // horizontal, vertical, diagonal, and other diagonal
        int[] directions = {1, w, w - 1, w + 1};

        // one loop for each possible legal move
        for (int i = 0; i < t.length; i++) {
            if (i % w >= 3 && i % w < w - 3 && i / w >= 3 && i / w < h - 3) {
                if (validateMove(i)) {

                    // one loop for each possible direction
                    for (int d = 0; d < directions.length; d++) {
                        int direction = directions[d];

                        // one loop for each possible set of 5 tiles in that direction including i
                        for (int offset = 0; offset <= 4; offset++) {

                            // analyze the five t from indexes start to end
                            int start = i - (offset * direction);
                            int end = start + (4 * direction);

                            // make sure start and end are in bounds
                            if (start < 0) break;
                            if (end >= w * h) continue;

                            // see how many in a row each player has
                            for (int p = 0; p < 2; p++) {
                                String match = p == 0 ? OPPONENT : USER;
                                double currentScore = match == USER ? 0.1 : 0; // defensive bias
                                for (int j = start; j <= end; j += direction) {
                                    if (j == i) continue;
                                    if (t[j] == match) {
                                        currentScore += 1;
                                    } else if (t[j] != EMPTY) {
                                        if (currentScore > bestScore && i < j) {
                                            bestScore = currentScore; // TO DO: add random to this
                                            bestMove = i;
                                        } else if (currentScore == 4.0) {
                                            return bestMove;
                                        }
                                        if (i < j) break;
                                        currentScore = 0;
                                    }
                                    if (j == end) {
                                        if (currentScore > bestScore) {
                                            bestScore = currentScore; // TO DO: add random to this
                                            bestMove = i;
                                        } else if (currentScore == 4.0) {
                                            return bestMove;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return bestMove;
    }

    public void scrollToCenter(View view) {
        int x = 40 + w * (32 + 4) / 2;
        int y = h * (32 + 2) / 2;
        hsv.scrollTo(x, y); // NOTE: doesn't work for y coordinate
    }

    // return the lower of the two possible middle tiles
    int getMiddle() {
        return (h * w + w) / 2;
    }

    // reset the game board
    public void reset(View view) {
        init();
        textView.setText("Connect 5 in a Row");
        scrollToCenter(view); // NOTE: don't need this since it's in init
        userCanMove = true;
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int m, long id) {
                onClick(m);
            }
        });
    }

    // initialize the game board
    void init() {
        for (int i = 0; i < t.length; i++) t[i] = EMPTY;

        // initialize the first two moves
        int middle = getMiddle();
        makeMove(middle, OPPONENT);
        makeMove(middle - w, USER);

        // initialize grid
        adjustGridSize();
        ((ArrayAdapter)gridView.getAdapter()).notifyDataSetChanged();

        // make sure scroll view is centered on the moves
        // NOTE: not working because gridview has not loaded yet
        scrollToCenter(null);
    }
}
