package edu.umb.cs443.hw2;

import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    GridView gridView;
    HorizontalScrollView hsv;
    TextView textView;

    private final String EMPTY = " ";
    private final String USER = "X";
    private final String OPPONENT = "O";

    // TO DO: height -> h, width -> w, position -> p, tiles -> t
    // 32 -> tilewidth

    private int height = 20; // must be even
    private int width = 19; // must be odd
    // private Random r = new Random();
    private String[] tiles = new String[height * width];
    private boolean userCanMove = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get references
        gridView = findViewById(R.id.gridView1);
        hsv = findViewById(R.id.scrollView);
        textView = findViewById(R.id.announcement);

        // create gridView to hold tiles
        gridView.setNumColumns(width);
        gridView.setAdapter(new ArrayAdapter<String>(this, R.layout.list_item, tiles));

        init();

        // click listener on all tiles
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                onClick(position);
            }
        });
    }

    void onClick(int position) {
        if (userCanMove && validateMove(position)) {
            userCanMove = false;

            // user makes move
            tiles[position] = USER;

            // expand board if needed
            if (position % width < 4) addTiles("left");
            else if (position % width >= width - 4) addTiles("right");
            else if (position / width < 4) addTiles("top");
            else if (position / width >= height - 4) addTiles("bottom");

            ((ArrayAdapter)gridView.getAdapter()).notifyDataSetChanged();

            // check win
            if (checkForWinner(USER)) {
                textView.setText("YOU WIN!");
            } else {
                textView.setText("Computer thinking...");
                Thread computer = new Thread (computerThread);
                computer.start();
            }

//            // computer makes move
//            position = computerMove();
//            tiles[position] = OPPONENT;
//            ((ArrayAdapter)gridView.getAdapter()).notifyDataSetChanged();
//
//            // expand board if needed
//            if (position % width < 4) addTiles("left");
//            else if (position % width >= width - 4) addTiles("right");
//            else if (position / width < 4) addTiles("top");
//            else if (position / width >= height - 4) addTiles("bottom");
//
//            // check win
//            if (checkForWinner(OPPONENT)) {
//                textView.setText("YOU LOSE.");
//                gridView.setOnItemClickListener(null);
//            } else {
//                textView.setText("Your turn");
//            }
//            ((ArrayAdapter)gridView.getAdapter()).notifyDataSetChanged();
        }
    }

    // check if a move is legal or not
    boolean validateMove(int position) {

        // NOTE: something is very wrong. I should not need this.
        if (position >= tiles.length) {
            return false;
        }

        if (!(position % width >= 3 && position % width < width - 3 && position / width >= 3 && position / width < height - 3)) {
            return false;
        }

        // check if tile is empty
        if (tiles[position] != EMPTY) return false;

        // if tile is close to the border then it cannot be a legal move
        if (position % width <= 1 || position % width >= width - 2
                || position / width <= 1 || position / width >= width - 2) {
            return false;
        }

        // check if an adjacent tile is filled
        return ((position % width != 0 && tiles[position - 1] != EMPTY)
            || (position + 1) % width != 0 && tiles[position + 1] != EMPTY
            || position >= width && tiles[position - width] != EMPTY
            || position <= height * (width - 1) && tiles[position + width] != EMPTY);
    }

    // check if one player has won the game
    boolean checkForWinner(String player) {
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] == player) {

                // horizontal
                if (tiles[i-2] == player && tiles[i-1] == player && tiles[i+1] == player && tiles[i+2] == player) {
                    return true;
                }

                // vertical
                if (tiles[i-width*2] == player && tiles[i-width] == player && tiles[i+width] == player && tiles[i+width*2] == player) {
                    return true;
                }

                // diagonal backslash
                if (tiles[i-width*2-2] == player && tiles[i-width-1] == player && tiles[i+width+1] == player && tiles[i+width*2+2] == player) {
                    return true;
                }

                // diagonal forwardslash
                if (tiles[i-width*2+2] == player && tiles[i-width+1] == player && tiles[i+width-1] == player && tiles[i+width*2-2] == player) {
                    return true;
                }
            }
        }
        return false;
    }

    // adds tiles to the board when needed, creating an infinite board
    void addTiles(String direction) {
        if (direction == "left") {
            width++;
            String[] newTiles = new String[height * width];
            int j = 0;
            for (int i = 0; i < tiles.length; i++) {
                if (j % width == 0) {
                    newTiles[j] = EMPTY;
                    j++;
                }
                newTiles[j] = tiles[i];
                j++;
            }
            tiles = newTiles;

            // adjust view
            int x = hsv.getScrollX();
            int y = hsv.getScrollY();
//            hsv.scrollTo(x + 32 + 4, y);
        }

        else if (direction == "right") {
            width++;
            String[] newTiles = new String[height * width];
            int j = 0;
            for (int i = 0; i < tiles.length; i++) {
                if (j % width == width - 1) {
                    newTiles[j] = EMPTY;
                    j++;
                }
                newTiles[j] = tiles[i];
                j++;
            }
            newTiles[height * width - 1] = EMPTY;
            tiles = newTiles;
        }

        else if (direction == "top") {
            height++;
            String[] newTiles = new String[height * width];
            for (int i = 0; i < width; i++) {
                newTiles[i] = EMPTY;
            }
            for (int i = 0; i < tiles.length; i++) {
                newTiles[i + width] = tiles[i];
            }
            tiles = newTiles;

            // adjust view
            int x = hsv.getScrollX();
            int y = hsv.getScrollY();
//            hsv.scrollTo(x, y + 32 + 4);
        }

        else if (direction == "bottom") {
            height++;
            String[] newTiles = new String[height * width];
            for (int i = 0; i < tiles.length; i++) {
                newTiles[i] = tiles[i];
            }
            for (int i = tiles.length; i < height * width; i++) {
                newTiles[i] = EMPTY;
            }
            tiles = newTiles;
        }

        // update grid with new data
        // NOTE: this causes errors when caleld from the thread
        gridView.setAdapter(null);
        gridView.setNumColumns(width);
        gridView.setAdapter(new ArrayAdapter<String>(this, R.layout.list_item, tiles));
    }

    // runnable for creating treasures
    private Runnable computerThread = new Runnable () {
        private static final int DELAY = 1000;

        public void run() {
            try {
                Thread.sleep(DELAY);

                int position = computerMove();
                tiles[position] = OPPONENT;

                // expand board if needed
                if (position % width < 4) addTiles("left");
                else if (position % width >= width - 4) addTiles("right");
                else if (position / width < 4) addTiles("top");
                else if (position / width >= height - 4) addTiles("bottom");

                threadHandler.sendEmptyMessage(0);

                userCanMove = true;

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };

    // handler allows threads to update the view
    public Handler threadHandler = new Handler() {
        public void handleMessage (android.os.Message message) {
            // check win
            if (checkForWinner(OPPONENT)) {
                textView.setText("YOU LOSE.");
                userCanMove = false;
            } else {
                textView.setText("Your turn");
            }
            ((ArrayAdapter) gridView.getAdapter()).notifyDataSetChanged();
        }
    };

    // calculate the best move in the current position
    // NOTE: I chose a simple approach. efficiency and accuracy can be improved
    int computerMove() {
        int bestMove = 1;
        double bestScore = -1;

        // horizontal, vertical, diagonal, and other diagonal
        int[] directions = {1, width, width - 1, width + 1};

        // one loop for each possible legal move
        for (int i = 0; i < tiles.length; i++) {
            if (i % width >= 3 && i % width < width - 3 && i / width >= 3 && i / width < height - 3) {
                if (i < tiles.length) { // NOTE: something is very wrong. I should not need this.
                    if (validateMove(i)) {

                        // one loop for each possible direction
                        for (int d = 0; d < directions.length; d++) {
                            int direction = directions[d];

                            // one loop for each possible set of 5 tiles in that direction including i
                            for (int offset = 0; offset <= 4; offset++) {

                                // analyze the five tiles from indexes start to end
                                int start = i - (offset * direction);
                                int end = start + (4 * direction);

                                // make sure start and end are in bounds
                                if (start < 0) break;
                                if (end >= width * height) continue;

                                // see how many in a row each player has
                                for (int player = 0; player < 2; player++) {
                                    String match = player == 0 ? OPPONENT : USER;
                                    double currentScore = match == USER ? 0.1 : 0; // defensive bias
                                    for (int j = start; j <= end; j += direction) {
                                        if (j == i) continue;
                                        if (tiles[j] == match) {
                                            currentScore += 1;
                                        } else if (tiles[j] != EMPTY) {
                                            if (currentScore > bestScore && i < j) {
                                                bestScore = currentScore; // TO DO: add random to this
                                                bestMove = i;
                                            } else if (currentScore == 4) {
                                                return bestMove;
                                            }
                                            if (i < j) break;
                                            currentScore = 0;
                                        }
                                        if (j == end) {
                                            if (currentScore > bestScore) {
                                                bestScore = currentScore; // TO DO: add random to this
                                                bestMove = i;
                                            } else if (currentScore == 4) {
                                                return bestMove;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return bestMove;
    }

    public void scrollToCenter(View view) {
        int x = width * (32 + 4) / 2;
        int y = height * (32 + 4) / 2;
        hsv.scrollTo(x, y);
    }

    // return the lower of the two possible middle tiles
    int getMiddle() {
        return (int) ((height * width + width) / 2);
    }

    // reset the game board
    public void reset(View view) {
        init();
        textView.setText("Connect 5 in a Row");

        scrollToCenter(view);

        userCanMove = true;

        // click listener on all tiles
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                onClick(position);
            }
        });
    }

    // initialize the game board
    void init() {
         for (int i = 0; i < tiles.length; i++) tiles[i] = EMPTY;

         // initialize the first two moves
         int middle = getMiddle();
         tiles[middle] = OPPONENT;
         tiles[middle - width] = USER;

         // r.nextInt(w);

        ((ArrayAdapter)gridView.getAdapter()).notifyDataSetChanged();

        // make sure scroll view is centered on the moves
        // NOTE: not working because gridview has not loaded yet
//        scrollToCenter(null);
    }
}
