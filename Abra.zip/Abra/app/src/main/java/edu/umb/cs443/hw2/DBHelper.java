package edu.umb.cs443.hw2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    //TASK 1: DEFINE THE DATABASE AND TABLE
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "abra";
    private static final String DATABASE_TABLE = "record";


    //TASK 2: DEFINE THE COLUMN NAMES FOR THE TABLE
    private static final String KEY_ID = "_id";
    private static final String KEY_WINS = "wins";
    private static final String KEY_LOSSES = "losses";

    public DBHelper (Context context){
        super (context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String table = "CREATE TABLE " + DATABASE_TABLE + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_WINS + " INTEGER, "
                + KEY_LOSSES + " INTEGER" + ")";
        db.execSQL(table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // DROP OLDER TABLE IF EXISTS
        database.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

        // CREATE TABLE AGAIN
        onCreate(database);
    }

    //********** DATABASE OPERATIONS:  ADD, EDIT, DELETE
    // Adding new task
    public void addToDoItem() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //ADD KEY-VALUE PAIR INFORMATION FOR THE TASK DESCRIPTION
        values.put(KEY_WINS, 0);
        values.put(KEY_LOSSES, 0);

        // INSERT THE ROW IN THE TABLE
        db.insert(DATABASE_TABLE, null, values);

        // CLOSE THE DATABASE CONNECTION
        db.close();
    }

    public int getValue(int index) {
        int value = -1;

        //SELECT ALL QUERY FROM THE TABLE
        String selectQuery = "SELECT  * FROM " + DATABASE_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // LOOP THROUGH THE TODO TASKS
        if (cursor.moveToFirst()) {
            do {
                value = cursor.getInt(index);
            } while (cursor.moveToNext());
        }

        // NOTE: this is a lame way to ensure that there is actually an entry in the table
        if (value == -1) {
            addToDoItem();
            value = 0;
        }

        // RETURN THE LIST OF TASKS FROM THE TABLE
        return value;
    }

    public int getWins() {
        return getValue(1);
    }

    public int getLosses() {
        return getValue(2);
    }

//    public void clearAll(List<ToDo_Item> list) {
//        //GET ALL THE LIST TASK ITEMS AND CLEAR THEM
//        list.clear();
//
//        SQLiteDatabase db = this.getWritableDatabase();
//        db.delete(DATABASE_TABLE, null, new String[]{});
//        db.close();
//    }

//    public void deleteSelected(List<ToDo_Item> list) {
//
//        for(Iterator<ToDo_Item> i=list.iterator() ; i.hasNext();){
//            ToDo_Item item=i.next();
//            if(item.getIs_done()==1) i.remove();
//        }
//        SQLiteDatabase db = this.getWritableDatabase();
//
//        db.delete(DATABASE_TABLE, KEY_IS_DONE+"=1", new String[]{});
//        db.close();
//    }

    public void updateWins(int wins) {
        updateValue(KEY_WINS, wins);
    }

    public void updateLosses(int losses) {
        updateValue(KEY_LOSSES, losses);
    }

    public void updateValue(String key, int value) {
        // updating row
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(key, value);

        db.update(DATABASE_TABLE, values,
                null, null);

        db.close();
    }

}

